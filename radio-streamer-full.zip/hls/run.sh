#!/bin/sh
set -e
for stream in $(ls /hls/config/*.yml); do
  echo "Launching FFmpeg for $stream"
  # Example: parse YAML manually or use env vars in production
done
