# Radio Streamer

## Run locally
```bash
cp .env.example .env
docker-compose up --build
```

Visit http://localhost:3000/admin to login (default admin: changeme).
