import React, { useState } from 'react'
import axios from 'axios'

export default function Settings({ token, onBack }) {
  const [currentPassword, setCurrentPassword] = useState('')
  const [newPassword, setNewPassword] = useState('')
  const [message, setMessage] = useState('')

  const handleSubmit = async (e) => {
    e.preventDefault()
    try {
      await axios.post('/api/auth/change-password', { currentPassword, newPassword }, { headers: { Authorization: `Bearer ${token}` } })
      setMessage('Password changed successfully')
    } catch (err) {
      setMessage('Error changing password')
    }
  }

  return (
    <div>
      <h2>Settings</h2>
      {message && <p>{message}</p>}
      <form onSubmit={handleSubmit}>
        <input type="password" placeholder="Current password" value={currentPassword} onChange={e => setCurrentPassword(e.target.value)} />
        <input type="password" placeholder="New password" value={newPassword} onChange={e => setNewPassword(e.target.value)} />
        <button type="submit">Change Password</button>
      </form>
      <button onClick={onBack}>Back</button>
    </div>
  )
}