import React,{useState,useEffect} from 'react'
import axios from 'axios'
import Settings from './Settings'
export default function Dashboard({token,onLogout}){
  const[streams,setStreams]=useState([]);
  const[showSettings,setShowSettings]=useState(false);
  useEffect(()=>{axios.get('/api/streams',{headers:{Authorization:`Bearer ${token}`}}).then(res=>setStreams(res.data))},[token]);
  if(showSettings) return <Settings token={token} onBack={()=>setShowSettings(false)}/>;
  return(<div>
    <h2>Streams</h2>
    <ul>{streams.map(s=><li key={s.id}>{s.name} - {s.sourceUrl}</li>)}</ul>
    <button onClick={()=>setShowSettings(true)}>Settings</button>
    <button onClick={onLogout}>Logout</button>
  </div>)
}
