import React,{useState} from 'react'
import Login from './screens/Login'
import Dashboard from './screens/Dashboard'
export default function App(){
  const[token,setToken]=useState(localStorage.getItem('token'));
  if(!token) return <Login onLogin={setToken}/>;
  return <Dashboard token={token} onLogout={()=>{localStorage.removeItem('token');setToken(null)}}/>;
}
