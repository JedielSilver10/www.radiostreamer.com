const express = require('express');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const cors = require('cors');
const path = require('path');
const sqlite3 = require('sqlite3').verbose();
const fs = require('fs');
require('dotenv').config();

const app = express();
app.use(express.json());
app.use(cors());

const DB_FILE = path.join(__dirname, 'radiostreamer.db');

if (!fs.existsSync(DB_FILE)) {
  const db = new sqlite3.Database(DB_FILE);
  db.serialize(() => {
    db.run("CREATE TABLE admins (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT, password_hash TEXT)");
    db.run("CREATE TABLE streams (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, sourceUrl TEXT)");
    db.run("INSERT INTO streams (name, sourceUrl) VALUES (?,?)", ["Example Radio 1", "https://example.com/stream1.m3u8"]);
    db.run("INSERT INTO streams (name, sourceUrl) VALUES (?,?)", ["Example Radio 2", "https://example.com/stream2.m3u8"]);
  });
  db.close();
}

const db = new sqlite3.Database(DB_FILE);

// Insert default admin
db.get("SELECT COUNT(*) as count FROM admins", async (err,row)=>{
  if(row.count===0){
    const hash = await bcrypt.hash(process.env.ADMIN_PASS || 'changeme', 12);
    db.run("INSERT INTO admins (username,password_hash) VALUES (?,?)", [process.env.ADMIN_USER || 'admin', hash]);
    console.log("Default admin user created.");
  }
});

// Serve React Admin UI
app.use('/admin', express.static(path.join(__dirname,'admin/dist')));
app.get('/admin/*', (req,res)=>res.sendFile(path.join(__dirname,'admin/dist/index.html')));

// Login
app.post('/api/auth/login', (req,res)=>{
  const { username, password } = req.body;
  db.get("SELECT * FROM admins WHERE username=?", [username], async (err,row)=>{
    if(!row) return res.status(401).json({error:'Invalid credentials'});
    const match = await bcrypt.compare(password,row.password_hash);
    if(!match) return res.status(401).json({error:'Invalid credentials'});
    const token = jwt.sign({ id: row.id }, process.env.JWT_SECRET || 'secretkey');
    res.json({token});
  });
});

// Change password
app.post('/api/auth/change-password', (req,res)=>{
  const { currentPassword, newPassword } = req.body;
  const token = req.headers.authorization?.split(' ')[1];
  if(!token) return res.status(401).json({error:'No token provided'});
  const decoded = jwt.verify(token, process.env.JWT_SECRET || 'secretkey');
  db.get("SELECT * FROM admins WHERE id=?", [decoded.id], async (err,row)=>{
    const match = await bcrypt.compare(currentPassword,row.password_hash);
    if(!match) return res.status(401).json({error:'Wrong password'});
    const hash = await bcrypt.hash(newPassword,12);
    db.run("UPDATE admins SET password_hash=? WHERE id=?", [hash,row.id]);
    res.json({success:true});
  });
});

// Streams endpoint
app.get('/api/streams', (req,res)=>{
  db.all("SELECT * FROM streams", (err, rows)=>{
    res.json(rows);
  });
});

const PORT = process.env.PORT || 7860;
app.listen(PORT, ()=>console.log(`Server running on port ${PORT}`));
