# Radio Streamer (Hugging Face Deployment)

This is a Node.js + React radio streamer admin panel.

## Deploy on Hugging Face

1. Create a new Space → select **Docker** as SDK.
2. Upload this project (or push via git).
3. Add secrets under **Settings → Variables and secrets**:
   - ADMIN_USER
   - ADMIN_PASS
   - JWT_SECRET
4. Deploy.

## Custom Domain Setup

To connect `www.radiostreamer.com`:

- In your domain registrar, add a **CNAME record**:

```
Name: www
Type: CNAME
Value: <your-username>-radiostreamer.hf.space
TTL: 3600
```

After propagation, `www.radiostreamer.com` will point to your Hugging Face Space.
